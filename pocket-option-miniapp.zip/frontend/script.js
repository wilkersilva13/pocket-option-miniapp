async function getSignal() {
    const instrument = document.getElementById('instrument').value;
    const time = document.getElementById('time').value;

    const res = await fetch(`http://localhost:3000/signal?instrument=${instrument}&time=${time}`);
    const data = await res.json();

    const box = document.getElementById('signalBox');
    box.style.display = 'block';
    box.innerHTML = `
        <strong>Instrument:</strong> ${data.instrument}<br>
        <strong>Time:</strong> ${data.time} min<br>
        <strong>Signal:</strong> ${data.signal}<br>
        <strong>Accuracy:</strong> ${data.accuracy}<br>
        <strong>Generated:</strong> ${new Date(data.timestamp).toLocaleTimeString()}
    `;
}
