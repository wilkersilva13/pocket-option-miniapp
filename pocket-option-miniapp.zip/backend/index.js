const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get('/signal', (req, res) => {
    const { instrument, time } = req.query;

    const signals = ['Buy', 'Sell'];
    const randomSignal = signals[Math.floor(Math.random() * signals.length)];
    const accuracy = (Math.random() * (99 - 80) + 80).toFixed(2); // 80% - 99%

    res.json({
        instrument,
        time,
        signal: randomSignal,
        accuracy: accuracy + '%',
        timestamp: new Date().toISOString()
    });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
